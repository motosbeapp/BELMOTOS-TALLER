
// BELMOTOS - Vanilla JS SPA Engine
import { generateOrderId, getOrders, saveOrders, seedDemoData } from './utils/storage.ts';
import { generateOrderPDF, generateTechnicalReportPDF } from './utils/pdf.ts';
import { CHECKLIST_DATA } from './constants.tsx';

const state = {
    activeTab: 'dashboard',
    orders: [],
    filters: {
        search: '',
        status: 'All'
    }
};

function init() {
    state.orders = getOrders();
    
    // Se eliminó la verificación que sembraba datos demo si no había órdenes
    
    document.querySelectorAll('[data-tab]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tab = link.getAttribute('data-tab');
            switchTab(tab);
        });
    });

    render();
}

function switchTab(tabId) {
    state.activeTab = tabId;
    document.querySelectorAll('[data-tab]').forEach(el => {
        if (el.getAttribute('data-tab') === tabId) el.classList.add('active');
        else el.classList.remove('active');
    });
    render();
}

function notify(text) {
    const el = document.getElementById('notification');
    const textEl = document.getElementById('notification-text');
    if (el && textEl) {
        textEl.innerText = text;
        el.style.display = 'block';
        setTimeout(() => { el.style.display = 'none'; }, 3000);
    }
}

function render() {
    const container = document.getElementById('app-container');
    if (!container) return;
    container.innerHTML = '';

    switch (state.activeTab) {
        case 'dashboard':
            container.innerHTML = renderDashboard();
            (window as any).initCharts();
            break;
        case 'reception':
            container.innerHTML = renderReceptionForm();
            bindReceptionEvents();
            break;
        case 'management':
            container.innerHTML = renderManagement();
            bindManagementEvents();
            break;
        case 'reports':
            container.innerHTML = renderReports();
            break;
    }
}

function renderDashboard() {
    const stats = {
        total: state.orders.length,
        pending: state.orders.filter((o: any) => o.status === 'Pendiente').length,
        process: state.orders.filter((o: any) => o.status === 'En Proceso').length,
        done: state.orders.filter((o: any) => o.status === 'Completado').length
    };

    return `
        <div class="animate-fade-in">
            <h2 class="fw-bold mb-4">Panel de Control</h2>
            <div class="row g-4 mb-5">
                ${renderStatCard('Total Vehículos', stats.total, 'fa-motorcycle', 'bg-white text-dark')}
                ${renderStatCard('Pendientes', stats.pending, 'fa-clock', 'bg-warning-subtle text-warning-emphasis')}
                ${renderStatCard('En Proceso', stats.process, 'fa-tools', 'bg-info-subtle text-info-emphasis')}
                ${renderStatCard('Completados', stats.done, 'fa-check-circle', 'bg-success-subtle text-success-emphasis')}
            </div>
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="card p-4">
                        <h5 class="fw-bold mb-4">Actividad Reciente</h5>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Orden</th>
                                        <th>Placa</th>
                                        <th>Cliente</th>
                                        <th>Estado</th>
                                        <th>Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${state.orders.slice(-5).reverse().map((o: any) => `
                                        <tr>
                                            <td>#${o.id}</td>
                                            <td><strong>${o.motorcycle.plate}</strong></td>
                                            <td>${o.owner.name}</td>
                                            <td><span class="badge rounded-pill ${getStatusBadgeClass(o.status)}">${o.status}</span></td>
                                            <td><button onclick="window.viewOrderModal('${o.id}')" class="btn btn-sm btn-outline-emerald"><i class="fas fa-eye"></i></button></td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                            ${state.orders.length === 0 ? '<p class="text-center py-4 text-muted italic">No hay órdenes registradas.</p>' : ''}
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card p-4 h-100">
                        <h5 class="fw-bold mb-4">Resumen Operativo</h5>
                        <canvas id="opChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderStatCard(title, value, icon, extraClass) {
    return `
        <div class="col-md-3">
            <div class="card p-3 h-100 ${extraClass}">
                <div class="d-flex align-items-center">
                    <div class="rounded-3 p-3 bg-white shadow-sm me-3 text-emerald">
                        <i class="fas ${icon} fa-2x"></i>
                    </div>
                    <div>
                        <p class="mb-0 text-muted small fw-bold uppercase">${title}</p>
                        <h3 class="mb-0 fw-bold">${value}</h3>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function getStatusBadgeClass(status) {
    switch (status) {
        case 'Pendiente': return 'bg-secondary';
        case 'En Proceso': return 'bg-primary';
        case 'Completado': return 'bg-success';
        default: return 'bg-light text-dark';
    }
}

// --- RECEPCIÓN ---
function renderReceptionForm() {
    const newId = generateOrderId();
    return `
        <div class="animate-fade-in pb-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-0">Recepción de Vehículo</h2>
                    <p class="text-muted">Orden de Servicio Automática: #${newId}</p>
                </div>
                <button type="button" id="btn-save-order" class="btn btn-emerald btn-lg px-5 shadow">
                    <i class="fas fa-save me-2"></i>Guardar Recepción
                </button>
            </div>

            <form id="reception-form" class="row g-4">
                <input type="hidden" name="id" value="${newId}">
                <input type="hidden" name="entryDate" value="${new Date().toISOString()}">
                
                <div class="col-lg-8">
                    <!-- Propietario -->
                    <div class="card p-4 mb-4 border-top border-4 border-success">
                        <h5 class="fw-bold mb-4 text-emerald"><i class="fas fa-user me-2"></i>Datos del Propietario</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Nombre</label>
                                <input type="text" name="ownerName" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Cédula</label>
                                <input type="text" name="ownerId" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Teléfono</label>
                                <input type="tel" name="ownerPhone" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Correo</label>
                                <input type="email" name="ownerEmail" class="form-control">
                            </div>
                        </div>
                    </div>

                    <!-- Motocicleta -->
                    <div class="card p-4 mb-4">
                        <h5 class="fw-bold mb-4 text-emerald"><i class="fas fa-motorcycle me-2"></i>Datos de la Motocicleta</h5>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Placa</label>
                                <input type="text" name="plate" class="form-control text-uppercase" required>
                            </div>
                            <div class="col-md-8">
                                <label class="form-label small fw-bold">Modelo</label>
                                <input type="text" name="model" class="form-control" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold">Año</label>
                                <input type="number" name="year" class="form-control">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small fw-bold">Color</label>
                                <input type="text" name="color" class="form-control">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Kilometraje</label>
                                <input type="number" name="mileage" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Serial Chasis</label>
                                <input type="text" name="chassis" class="form-control">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Serial Motor</label>
                                <input type="text" name="engine" class="form-control">
                            </div>
                        </div>
                    </div>

                    <!-- Fotos -->
                    <div class="row g-4 mb-4">
                        <div class="col-md-6">
                            <div class="card p-4 text-center">
                                <label class="form-label small fw-bold d-block mb-3">Foto del Vehículo</label>
                                <div id="preview-vehicle" class="mb-3 bg-light rounded" style="height: 150px; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-camera fa-2x text-muted"></i>
                                </div>
                                <input type="file" id="input-photo-vehicle" class="form-control form-control-sm" accept="image/*">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card p-4 text-center">
                                <label class="form-label small fw-bold d-block mb-3">Foto del Chasis/Serial</label>
                                <div id="preview-chassis" class="mb-3 bg-light rounded" style="height: 150px; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-fingerprint fa-2x text-muted"></i>
                                </div>
                                <input type="file" id="input-photo-chassis" class="form-control form-control-sm" accept="image/*">
                            </div>
                        </div>
                    </div>

                    <!-- Reporte -->
                    <div class="card p-4 mb-4">
                        <h5 class="fw-bold mb-4 text-emerald"><i class="fas fa-clipboard-list me-2"></i>Reporte y Notas</h5>
                        <label class="form-label small fw-bold">Reporte del Cliente</label>
                        <textarea name="clientReport" class="form-control mb-3" rows="3" required placeholder="Fallas reportadas..."></textarea>
                        <label class="form-label small fw-bold">Observaciones Generales</label>
                        <textarea name="observations" class="form-control" rows="2" placeholder="Rayones, accesorios..."></textarea>
                    </div>

                    <!-- Condiciones del Servicio -->
                    <div class="card p-4 bg-amber-50 border-amber-200">
                        <h6 class="fw-bold text-amber-900 mb-3"><i class="fas fa-shield-alt me-2"></i>Condiciones del Servicio</h6>
                        <div class="text-xs text-amber-800" style="font-size: 0.75rem; line-height: 1.5;">
                            <p class="mb-2"><strong>Condiciones:</strong> En caso de incendio, accidentes, terremotos, la empresa no responderá por los desperfectos ocasionados a la motocicleta, ni por los objetos dejados en ella.</p>
                            <p class="mb-2">Todos los trabajos realizados a la motocicleta deberán ser cancelados en el momento de su retiro.</p>
                            <p class="mb-2">En el caso que la reparación necesite de la preparación de un presupuesto, una vez dado a conocer se otorga un plazo de 24 horas para autorizar o no el mismo, y el cliente en el segundo de los casos deberá retirar la motocicleta al vencer el mismo plazo.</p>
                            <p class="mb-0">Se entiende que quien contrata y ordena el trabajo descrito, es el propietario de la motocicleta, o está autorizado por el propietario quien conoce y acepta estas condiciones que son parte integrante del contrato que se celebra y que consta en este documento.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card p-4 mb-4">
                        <h5 class="fw-bold mb-4 text-emerald"><i class="fas fa-cog me-2"></i>Configuración</h5>
                        <label class="form-label small fw-bold">Tipo de Operación</label>
                        <select name="opType" class="form-select mb-3">
                            <option value="Revisión">Revisión/Mantenimiento</option>
                            <option value="Reparación">Reparación General</option>
                            <option value="Garantía">Garantía</option>
                        </select>
                    </div>

                    <div class="card p-4">
                        <h5 class="fw-bold mb-4 text-emerald"><i class="fas fa-list-check me-2"></i>Checklist (Inventario)</h5>
                        <div class="overflow-auto" style="max-height: 600px;">
                            ${CHECKLIST_DATA.map((cat, catIdx) => `
                                <div class="mb-4">
                                    <h6 class="text-xs font-bold text-emerald-700 border-b border-emerald-50 pb-1 mb-2 uppercase">${cat.category}</h6>
                                    ${cat.items.map((item, itemIdx) => `
                                        <div class="form-check mb-1">
                                            <input class="form-check-input checklist-item" type="checkbox" checked id="chk-${catIdx}-${itemIdx}" data-item="${item}">
                                            <label class="form-check-label text-xs" for="chk-${catIdx}-${itemIdx}">${item}</label>
                                        </div>
                                    `).join('')}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </form>
        </div>
    `;
}

function bindReceptionEvents() {
    const photoState = { vehicle: null, chassis: null };

    const handlePhoto = (inputId, previewId, key) => {
        const input = document.getElementById(inputId) as HTMLInputElement;
        const preview = document.getElementById(previewId);
        input?.addEventListener('change', (e: any) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (re: any) => {
                    photoState[key] = re.target.result;
                    if (preview) preview.innerHTML = `<img src="${re.target.result}" style="max-height: 100%; max-width: 100%; border-radius: 8px;">`;
                };
                reader.readAsDataURL(file);
            }
        });
    };

    handlePhoto('input-photo-vehicle', 'preview-vehicle', 'vehicle');
    handlePhoto('input-photo-chassis', 'preview-chassis', 'chassis');

    document.getElementById('btn-save-order')?.addEventListener('click', () => {
        const form = document.getElementById('reception-form') as HTMLFormElement;
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const fd = new FormData(form);
        const checklist = {};
        document.querySelectorAll('.checklist-item').forEach((el: any) => {
            checklist[el.dataset.item] = el.checked;
        });

        const newOrder = {
            id: fd.get('id'),
            entryDate: fd.get('entryDate'),
            operationType: fd.get('opType'),
            status: 'Pendiente',
            owner: {
                name: fd.get('ownerName'),
                idNumber: fd.get('ownerId'),
                phone: fd.get('ownerPhone'),
                email: fd.get('ownerEmail')
            },
            motorcycle: {
                plate: fd.get('plate'),
                model: fd.get('model'),
                year: fd.get('year'),
                color: fd.get('color'),
                mileage: fd.get('mileage'),
                chassisSerial: fd.get('chassis'),
                engineSerial: fd.get('engine'),
                displacement: ''
            },
            clientReport: fd.get('clientReport'),
            observations: fd.get('observations'),
            checklist: checklist,
            photoVehicle: photoState.vehicle,
            photoChassis: photoState.chassis,
            updates: [],
            workHours: 0,
            technicianNotes: '',
            estimatedCost: 0
        };

        (state.orders as any).push(newOrder);
        saveOrders(state.orders);
        generateOrderPDF(newOrder as any);
        notify('¡Orden guardada con éxito! Generando comprobante...');
        switchTab('management');
    });
}

// --- GESTIÓN ---
function renderManagement() {
    return `
        <div class="animate-fade-in">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold mb-0">Gestión de Trabajos</h2>
                <div class="d-flex gap-2">
                    <input type="text" class="form-control" placeholder="Placa o ID..." id="search-input" value="${state.filters.search}">
                    <select class="form-select w-auto" id="filter-status">
                        <option value="All" ${state.filters.status === 'All' ? 'selected' : ''}>Todos</option>
                        <option value="Pendiente" ${state.filters.status === 'Pendiente' ? 'selected' : ''}>Pendientes</option>
                        <option value="En Proceso" ${state.filters.status === 'En Proceso' ? 'selected' : ''}>En Proceso</option>
                        <option value="Completado" ${state.filters.status === 'Completado' ? 'selected' : ''}>Completados</option>
                    </select>
                </div>
            </div>

            <div class="row g-4" id="orders-list">
                ${renderOrdersList()}
            </div>
        </div>

        <!-- Modal de Edición Técnica -->
        <div class="modal fade" id="orderEditModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content border-0 rounded-4 shadow" id="modal-content-area">
                    <!-- Dinámico -->
                </div>
            </div>
        </div>
    `;
}

function renderOrdersList() {
    const filtered = state.orders.filter((o: any) => {
        const matchSearch = o.motorcycle.plate.toLowerCase().includes(state.filters.search.toLowerCase()) || o.id.includes(state.filters.search);
        const matchStatus = state.filters.status === 'All' || o.status === state.filters.status;
        return matchSearch && matchStatus;
    }).reverse();

    if (filtered.length === 0) return '<div class="col-12 text-center py-5"><p class="text-muted">No se encontraron órdenes.</p></div>';

    return filtered.map((o: any) => `
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 p-4 border-start border-4 ${getStatusBorder(o.status)}">
                <div class="d-flex justify-content-between mb-3">
                    <span class="text-muted small fw-bold">#${o.id}</span>
                    <span class="badge ${getStatusBadgeClass(o.status)}">${o.status}</span>
                </div>
                <h4 class="fw-bold mb-1">${o.motorcycle.plate}</h4>
                <p class="text-muted mb-3">${o.motorcycle.model}</p>
                <div class="d-flex align-items-center mb-4 text-muted small">
                    <i class="fas fa-user me-2"></i> ${o.owner.name}
                </div>
                <div class="mt-auto d-flex gap-2">
                    <button onclick="window.viewOrderModal('${o.id}')" class="btn btn-sm btn-emerald flex-grow-1"><i class="fas fa-edit me-2"></i>Gestionar</button>
                    <button onclick="window.viewOrderPDF('${o.id}')" class="btn btn-sm btn-light text-emerald" title="Ficha Recepción"><i class="fas fa-file-invoice"></i></button>
                </div>
            </div>
        </div>
    `).join('');
}

function getStatusBorder(status) {
    switch (status) {
        case 'Pendiente': return 'border-secondary';
        case 'En Proceso': return 'border-primary';
        case 'Completado': return 'border-success';
        default: return '';
    }
}

function bindManagementEvents() {
    document.getElementById('search-input')?.addEventListener('input', (e: any) => {
        state.filters.search = e.target.value;
        const list = document.getElementById('orders-list');
        if (list) list.innerHTML = renderOrdersList();
    });
    document.getElementById('filter-status')?.addEventListener('change', (e: any) => {
        state.filters.status = e.target.value;
        const list = document.getElementById('orders-list');
        if (list) list.innerHTML = renderOrdersList();
    });
}

// --- MODAL DE GESTIÓN ---
(window as any).viewOrderModal = (id) => {
    const order = state.orders.find((o: any) => o.id === id) as any;
    if (!order) return;

    const modalArea = document.getElementById('modal-content-area');
    if (!modalArea) return;

    modalArea.innerHTML = `
        <div class="modal-header bg-light">
            <div>
                <h5 class="modal-title fw-bold">Gestión de Orden #${order.id}</h5>
                <small class="text-muted">${order.motorcycle.plate} - ${order.motorcycle.model}</small>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label small fw-bold">Estado del Trabajo</label>
                    <select id="modal-status" class="form-select mb-3">
                        <option value="Pendiente" ${order.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
                        <option value="En Proceso" ${order.status === 'En Proceso' ? 'selected' : ''}>En Proceso</option>
                        <option value="Completado" ${order.status === 'Completado' ? 'selected' : ''}>Completado</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Horas</label>
                    <input type="number" id="modal-hours" class="form-control" value="${order.workHours || 0}" step="0.5">
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold">Costo ($)</label>
                    <input type="number" id="modal-cost" class="form-control" value="${order.estimatedCost || 0}">
                </div>
                <div class="col-12">
                    <label class="form-label small fw-bold">Notas Técnicas / Diagnóstico Final</label>
                    <textarea id="modal-notes" class="form-control" rows="4" placeholder="Describa el trabajo realizado...">${order.technicianNotes || ''}</textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer bg-light">
            <button type="button" class="btn btn-outline-danger me-auto" onclick="window.deleteOrder('${order.id}')">Eliminar</button>
            <button type="button" class="btn btn-outline-emerald" onclick="window.printTechReport('${order.id}')">
                <i class="fas fa-file-pdf me-2"></i>Informe Técnico
            </button>
            <button type="button" class="btn btn-emerald px-4" onclick="window.saveOrderChanges('${order.id}')">Guardar Cambios</button>
        </div>
    `;

    // @ts-ignore
    const modal = new bootstrap.Modal(document.getElementById('orderEditModal'));
    modal.show();
};

(window as any).saveOrderChanges = (id) => {
    const order = state.orders.find((o: any) => o.id === id) as any;
    if (!order) return;

    order.status = (document.getElementById('modal-status') as HTMLSelectElement).value;
    order.workHours = parseFloat((document.getElementById('modal-hours') as HTMLInputElement).value) || 0;
    order.estimatedCost = parseFloat((document.getElementById('modal-cost') as HTMLInputElement).value) || 0;
    order.technicianNotes = (document.getElementById('modal-notes') as HTMLTextAreaElement).value;

    if (order.status === 'Completado' && !order.completionDate) {
        order.completionDate = new Date().toISOString();
    }

    saveOrders(state.orders);
    notify('Orden actualizada exitosamente.');
    
    // @ts-ignore
    const modal = bootstrap.Modal.getInstance(document.getElementById('orderEditModal'));
    modal.hide();
    render();
};

(window as any).deleteOrder = (id) => {
    if (confirm('¿Está seguro de eliminar esta orden? Esta acción es irreversible.')) {
        state.orders = state.orders.filter((o: any) => o.id !== id);
        saveOrders(state.orders);
        // @ts-ignore
        const modal = bootstrap.Modal.getInstance(document.getElementById('orderEditModal'));
        if (modal) modal.hide();
        render();
        notify('Orden eliminada.');
    }
};

(window as any).viewOrderPDF = (id) => {
    const order = state.orders.find((o: any) => o.id === id);
    if (order) generateOrderPDF(order as any);
};

(window as any).printTechReport = (id) => {
    const order = state.orders.find((o: any) => o.id === id);
    if (order) generateTechnicalReportPDF(order as any);
};

(window as any).initCharts = () => {
    const ctx = document.getElementById('opChart') as HTMLCanvasElement;
    if (!ctx) return;
    new (window as any).Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pendiente', 'Proceso', 'Listos'],
            datasets: [{
                data: [
                    state.orders.filter((o: any) => o.status === 'Pendiente').length,
                    state.orders.filter((o: any) => o.status === 'En Proceso').length,
                    state.orders.filter((o: any) => o.status === 'Completado').length
                ],
                backgroundColor: ['#94a3b8', '#3b82f6', '#10b981']
            }]
        },
        options: { plugins: { legend: { position: 'bottom' } } }
    });
};

function renderReports() {
    return `
        <div class="animate-fade-in">
            <h2 class="fw-bold mb-4">Reportes y Estadísticas</h2>
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="card p-4 bg-emerald text-white shadow">
                        <p class="small fw-bold uppercase mb-1">Ingresos Estimados</p>
                        <h2 class="fw-bold">$ ${state.orders.reduce((acc, o: any) => acc + (o.estimatedCost || 0), 0).toLocaleString()}</h2>
                    </div>
                </div>
            </div>
            <div class="card p-5 text-center bg-light border-0 rounded-4">
                <i class="fas fa-chart-bar fa-3x text-emerald mb-3"></i>
                <h4 class="fw-bold">Reportes Avanzados</h4>
                <p class="text-muted">El sistema de analítica procesa el historial de trabajos para generar KPIs de eficiencia y tiempos promedio.</p>
                <div class="d-flex justify-content-center gap-2 mt-3">
                    <button class="btn btn-emerald px-4"><i class="fas fa-file-excel me-2"></i>Exportar Excel</button>
                    <button class="btn btn-outline-emerald px-4"><i class="fas fa-file-pdf me-2"></i>Reporte Mensual</button>
                </div>
            </div>
        </div>
    `;
}

document.addEventListener('DOMContentLoaded', init);
