
import { jsPDF } from 'jspdf';
import { WorkshopOrder } from '../types.ts';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export const generateOrderPDF = (order: WorkshopOrder) => {
  // @ts-ignore
  const doc = new jsPDF();
  const margin = 15;
  let y = 15;

  // Header
  doc.setFontSize(22);
  doc.setTextColor(5, 150, 105);
  doc.setFont('helvetica', 'bold');
  doc.text('BELMOTOS-TALLER', margin, y);
  
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.setFont('helvetica', 'normal');
  doc.text('Control Profesional de Recepción y Servicio de Motocicletas', margin, y + 6);
  
  doc.setFontSize(14);
  doc.setTextColor(0);
  doc.text(`ORDEN: #${order.id}`, 160, y + 3);
  y += 22;

  // Header Info Box
  doc.setDrawColor(220);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(margin, y, 180, 20, 3, 3, 'F');
  
  doc.setFontSize(9);
  doc.text(`Fecha Ingreso: ${format(new Date(order.entryDate), 'PPP p', { locale: es })}`, margin + 5, y + 8);
  doc.text(`Operación: ${order.operationType}`, margin + 5, y + 14);
  doc.text(`Estado: ${order.status}`, 140, y + 11);
  y += 28;

  // Customer & Vehicle Table
  doc.setFont('helvetica', 'bold');
  doc.text('DATOS DEL PROPIETARIO', margin, y);
  doc.text('DATOS DEL VEHÍCULO', 105, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  
  const drawCol = (x, data) => {
    let internalY = y;
    data.forEach(line => {
      doc.text(line, x, internalY);
      internalY += 5;
    });
  };

  drawCol(margin, [
    `Nombre: ${order.owner.name}`,
    `CI/RIF: ${order.owner.idNumber}`,
    `Teléfono: ${order.owner.phone}`,
    `Email: ${order.owner.email || 'N/A'}`
  ]);

  drawCol(105, [
    `Placa: ${order.motorcycle.plate}`,
    `Modelo: ${order.motorcycle.model}`,
    `KM: ${order.motorcycle.mileage}`,
    `Año: ${order.motorcycle.year} | Color: ${order.motorcycle.color}`,
    `Chasis: ${order.motorcycle.chassisSerial}`,
    `Motor: ${order.motorcycle.engineSerial}`
  ]);
  y += 35;

  // Checklist
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('INVENTARIO Y ESTADO FÍSICO (CHECKLIST)', margin, y);
  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  
  const checklist = Object.entries(order.checklist);
  const rows = Math.ceil(checklist.length / 3);
  checklist.forEach(([item, checked], i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const mark = checked ? '[X]' : '[ ]';
    
    // Ajustar largo máximo del texto para evitar solapamiento entre las 3 columnas
    let fullText = `${mark} ${item}`;
    if (fullText.length > 53) {
      fullText = fullText.substring(0, 50) + "...";
    }
    
    doc.text(fullText, margin + (col * 60), y + (row * 4.5));
  });
  y += (rows * 4.5) + 10;

  // Client Report
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('REPORTE DEL CLIENTE:', margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  const splitReport = doc.splitTextToSize(order.clientReport || 'Sin reporte.', 180);
  doc.text(splitReport, margin, y);
  y += (splitReport.length * 4.5) + 8;

  // Observations
  doc.setFont('helvetica', 'bold');
  doc.text('OBSERVACIONES GENERALES:', margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  const splitObs = doc.splitTextToSize(order.observations || 'Sin observaciones.', 180);
  doc.text(splitObs, margin, y);
  y += (splitObs.length * 4.5) + 10;

  // Photos
  if (order.photoVehicle || order.photoChassis) {
    if (y > 200) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold');
    doc.text('EVIDENCIA FOTOGRÁFICA DE INGRESO:', margin, y);
    y += 5;
    if (order.photoVehicle) {
      try {
        doc.addImage(order.photoVehicle, 'JPEG', margin, y, 85, 60);
      } catch (e) { console.error("Error adding vehicle image", e); }
    }
    if (order.photoChassis) {
      try {
        doc.addImage(order.photoChassis, 'JPEG', margin + 95, y, 85, 60);
      } catch (e) { console.error("Error adding chassis image", e); }
    }
    y += 65;
  }

  // Legal Conditions
  if (y > 230) { doc.addPage(); y = 20; }
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('CONDICIONES DEL SERVICIO:', margin, y);
  y += 4;
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(6.5);
  const legalText = "Condiciones: En caso de incendio, accidentes, terremotos, la empresa no responderá por los desperfectos ocasionados a la motocicleta, ni por los objetos dejados en ella. Todos los trabajos realizados a la motocicleta deberán ser cancelados en el momento de su retiro. En el caso que la reparación necesite de la preparación de un presupuesto, una vez dado a conocer se otorga un plazo de 24 horas para autorizar o no el mismo, y el cliente en el segundo de los casos deberá retirar la motocicleta al vencer el mismo plazo. Se entiende que quien contrata y ordena el trabajo descrito, es el propietario de la motocicleta, o está autorizado por el propietario quien conoce y acepta estas condiciones que son parte integrante del contrato que se celebra y que consta en este documento.";
  const splitLegal = doc.splitTextToSize(legalText, 180);
  doc.text(splitLegal, margin, y);
  y += (splitLegal.length * 3.5) + 5;

  // Signatures
  y = 265;
  doc.line(margin, y, 80, y);
  doc.line(120, y, 195, y);
  doc.setFontSize(7);
  doc.setFont('helvetica', 'normal');
  doc.text('FIRMA RECIBIDO (TALLER)', margin + 15, y + 4);
  doc.text('FIRMA CONFORMIDAD (CLIENTE)', 135, y + 4);

  doc.save(`Recepcion_${order.motorcycle.plate}_${order.id}.pdf`);
};

export const generateTechnicalReportPDF = (order: WorkshopOrder) => {
  // @ts-ignore
  const doc = new jsPDF();
  const margin = 20;
  let y = 20;

  doc.setFontSize(24);
  doc.setTextColor(30, 64, 175);
  doc.text('INFORME TÉCNICO FINAL', margin, y);
  y += 10;

  doc.setFontSize(10);
  doc.setTextColor(0);
  doc.text(`Orden Ref: #${order.id}`, margin, y);
  doc.text(`Fecha Entrega: ${format(new Date(), 'PPP', { locale: es })}`, 130, y);
  y += 15;

  doc.setDrawColor(200);
  doc.line(margin, y, 190, y);
  y += 10;

  doc.setFont('helvetica', 'bold');
  doc.text('DETALLES DEL TRABAJO:', margin, y);
  y += 8;
  doc.setFont('helvetica', 'normal');
  const notes = doc.splitTextToSize(order.technicianNotes || 'No se registraron notas técnicas.', 170);
  doc.text(notes, margin, y);
  y += (notes.length * 5) + 15;

  doc.setFont('helvetica', 'bold');
  doc.text('RESUMEN DE CARGOS:', margin, y);
  y += 8;
  doc.setFont('helvetica', 'normal');
  doc.text(`Mano de obra (Horas): ${order.workHours}`, margin, y);
  doc.text(`Costo Total del Servicio: $ ${order.estimatedCost?.toLocaleString()}`, margin, y + 6);
  y += 30;

  doc.text('Gracias por confiar en BELMOTOS.', margin, y);

  doc.save(`InformeTecnico_${order.motorcycle.plate}_${order.id}.pdf`);
};
